Thank you for purchasing this 3d model.

Don't forget to rate the model you purchased on the voting page!! It's very important for us!

For questions, requests, personalized orders, format conversions, complaints
write to:

duchampmodels@gmail.com

or visit:

http://www.seemonkey.com/duchamp_models  


Duchamp Models.

--------------------------------------------------
